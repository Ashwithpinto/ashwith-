package sample;

/**
 * Created by Mitra on 9/9/2017.
 */
public interface FilePath {

    public static final String FOLDER_PATH="ashwith2/";

	public static final String JSON_PATH_1="C:/ashwith2/";

    public static final String JSON_PATH_2=JSON_PATH_1+"IP_DRIVE_CONFING/";

    public static final String DATA_BACKUP_PATH=FOLDER_PATH+"DATA_BACK_UP/";

    public static final String PAYEMNT_DETAILS_PATH=FOLDER_PATH+"PAYMENT_DETAILS/";

    public static final String GSTREPORT_INVOICEWISE_PATH=FOLDER_PATH+"GSTREPORT/";

}